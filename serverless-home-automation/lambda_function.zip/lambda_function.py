from flask import Flask, render_template, json
from flask_ask import Ask, statement, question, session
import json
import requests
import paho.mqtt.client as mqtt
import os
#from urllib.parse import urlparse
import urllib.parse as urlparse


mqttc = mqtt.Client()
url_str = os.environ.get('CLOUDMQTT_URL', os.environ['MQTT_URL'])
url = urlparse.urlparse(url_str)
topic = '/request'
mqttc.username_pw_set(os.environ['MQTT_USERNAME'], os.environ['MQTT_PASSWORD'])
mqttc.connect(url.hostname, url.port)
mqttc.subscribe(topic, 0)

app = Flask(__name__)
ask = Ask(app, '/')

def lambda_handler(event, _context):
    return ask.run_aws_lambda(event)

# will run on invocation
@ask.launch
def launched():
	return question('connected!!')

# when something goes wrong
@ask.default_intent
def default_message():
    speech = "Oh-aw! I couldn't understand you. Please try again"
    return question(speech)

@ask.intent('LightOnIntent')
def light_on():
	mqttc.publish(topic, "on")
	return statement("switching light on")

@ask.intent('LightDimIntent')
def light_dim():
	mqttc.publish(topic, "dim_on")
	return statement("switching dim light on")

@ask.intent('LightOffIntent')
def light_off():
	mqttc.publish(topic, "off")
	return statement("switching light off")

if __name__ == '__main__':
    app.run(debug=True)


