========================================================
pyOpenSSL -- A Python wrapper around the OpenSSL library
========================================================

.. image:: https://readthedocs.org/projects/pyopenssl/badge/?version=stable
   :target: https://pyopenssl.readthedocs.io/
   :alt: Stable Docs

.. image:: https://travis-ci.org/pyca/pyopenssl.svg?branch=master
   :target: https://travis-ci.org/pyca/pyopenssl
   :alt: Build status

.. image:: https://codecov.io/github/pyca/pyopenssl/branch/master/graph/badge.svg
   :target: https://codecov.io/github/pyca/pyopenssl
   :alt: Test coverage


High-level wrapper around a subset of the OpenSSL library.  Includes

* ``SSL.Connection`` objects, wrapping the methods of Python's portable sockets
* Callbacks written in Python
* Extensive error-handling mechanism, mirroring OpenSSL's error codes

... and much more.

You can find more information in the documentation_.
Development takes place on GitHub_.


Discussion
==========

If you run into bugs, you can file them in our `issue tracker`_.

We maintain a cryptography-dev_ mailing list for both user and development discussions.

You can also join ``#cryptography-dev`` on Freenode to ask questions or get involved.


.. _documentation: https://pyopenssl.readthedocs.io/
.. _`issue tracker`: https://github.com/pyca/pyopenssl/issues
.. _cryptography-dev: https://mail.python.org/mailman/listinfo/cryptography-dev
.. _GitHub: https://github.com/pyca/pyopenssl


Release Information
===================

17.0.0 (2017-04-20)
-------------------

Backward-incompatible changes:
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

*none*


Deprecations:
^^^^^^^^^^^^^

*none*


Changes:
^^^^^^^^

- Added ``OpenSSL.X509Store.set_time()`` to set a custom verification time when verifying certificate chains.
  `#567 <https://github.com/pyca/pyopenssl/pull/567>`_
- Added a collection of functions for working with OCSP stapling.
  None of these functions make it possible to validate OCSP assertions, only to staple them into the handshake and to retrieve the stapled assertion if provided.
  Users will need to write their own code to handle OCSP assertions.
  We specifically added: ``Context.set_ocsp_server_callback``, ``Context.set_ocsp_client_callback``, and ``Connection.request_ocsp``.
  `#580 <https://github.com/pyca/pyopenssl/pull/580>`_
- Changed the ``SSL`` module's memory allocation policy to avoid zeroing memory it allocates when unnecessary.
  This reduces CPU usage and memory allocation time by an amount proportional to the size of the allocation.
  For applications that process a lot of TLS data or that use very lage allocations this can provide considerable performance improvements.
  `#578 <https://github.com/pyca/pyopenssl/pull/578>`_
- Automatically set ``SSL_CTX_set_ecdh_auto()`` on ``OpenSSL.SSL.Context``.
  `#575 <https://github.com/pyca/pyopenssl/pull/575>`_
- Fix empty exceptions from ``OpenSSL.crypto.load_privatekey()``.
  `#581 <https://github.com/pyca/pyopenssl/pull/581>`_

`Full changelog <https://pyopenssl.readthedocs.io/en/stable/changelog.html>`_.



